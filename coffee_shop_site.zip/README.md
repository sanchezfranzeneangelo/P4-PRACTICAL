# Bean & Brew - Mini Coffee Shop Website
This project is a small multi-page website created for a college assignment demonstrating HTML, CSS, JavaScript features, version control, and deployment preparation.

Files:
- index.html (Home)
- about.html (Menu)
- contact.html (Contact with form validation)
- styles.css (Styling)
- script.js (Interactivity)
